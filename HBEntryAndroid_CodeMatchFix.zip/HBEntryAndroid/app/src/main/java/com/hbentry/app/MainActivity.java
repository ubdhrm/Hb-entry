package com.hbentry.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 5001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);
        configureWebView(webView, true);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void configureWebView(final WebView wv, final boolean isMain) {
        WebSettings settings = wv.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        wv.setWebViewClient(new WebViewClient());
        wv.addJavascriptInterface(new DownloadBridge(this), "AndroidDownload");

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.confirm())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .setCancelable(true)
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                              FileChooserParams params) {
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            // "Saved bills" opens via window.open('', '_blank'); show it in a
            // full-screen dialog backed by its own WebView with the same bridges.
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                final Dialog dialog = new Dialog(MainActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                FrameLayout container = new FrameLayout(MainActivity.this);
                final WebView popupWebView = new WebView(MainActivity.this);
                configureWebView(popupWebView, false);
                container.addView(popupWebView, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                dialog.setContentView(container);
                Window window = dialog.getWindow();
                if (window != null) {
                    window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                }
                dialog.setOnDismissListener(d -> popupWebView.destroy());
                popupWebView.setWebViewClient(new WebViewClient());

                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popupWebView);
                resultMsg.sendToTarget();

                dialog.show();
                popupWebView.setOnKeyListener((v, keyCode, event) -> {
                    if (keyCode == android.view.KeyEvent.KEYCODE_BACK && popupWebView.canGoBack()) {
                        popupWebView.goBack();
                        return true;
                    }
                    return false;
                });
                // Allow closing the popup with the system back gesture/button.
                dialog.setCancelable(true);
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                } else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    /**
     * Shows a full HTML string (built entirely in JS, e.g. the "Saved bills"
     * screen) in a full-screen dialog backed by its own WebView, loaded via
     * loadDataWithBaseURL so it counts as a real page load. That matters
     * because android.webkit.WebView only binds addJavascriptInterface
     * objects (like AndroidDownload) on to a page's JS context during an
     * actual navigation/load — a WebView that only ever receives content via
     * document.write() (as window.open() + document.write() does) never gets
     * the bridge, which is why the WhatsApp share button silently couldn't
     * reach AndroidDownload before this method existed.
     */
    void showHtmlDialog(String html) {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout container = new FrameLayout(this);
        final WebView popupWebView = new WebView(this);
        configureWebView(popupWebView, false);
        container.addView(popupWebView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        dialog.setContentView(container);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        dialog.setOnDismissListener(d -> popupWebView.destroy());
        popupWebView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        dialog.show();
        popupWebView.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && popupWebView.canGoBack()) {
                popupWebView.goBack();
                return true;
            }
            return false;
        });
        dialog.setCancelable(true);
    }

    /**
     * JS bridge that receives a base64-encoded file (PDF/JSON export produced by
     * the page's own download buttons) and saves it to the device's Downloads,
     * then offers a share sheet (so "WhatsApp" buttons work the same as on the web).
     */
    public static class DownloadBridge {
        private final Context context;

        DownloadBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void openHtmlWindow(final String html) {
            if (!(context instanceof MainActivity)) return;
            final MainActivity activity = (MainActivity) context;
            activity.runOnUiThread(() -> activity.showHtmlDialog(html));
        }

        @JavascriptInterface
        public void saveBase64File(final String base64Data, final String filename, final String mimeType) {
            ((Activity) context).runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                    Uri savedUri = writeToDownloads(bytes, filename, mimeType);
                    if (savedUri == null) {
                        Toast.makeText(context, "Could not save " + filename, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(context, "Saved to Downloads: " + filename, Toast.LENGTH_SHORT).show();

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType(mimeType != null ? mimeType : "application/octet-stream");
                    share.putExtra(Intent.EXTRA_STREAM, savedUri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(share, "Share " + filename);
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(chooser);
                } catch (Exception e) {
                    Toast.makeText(context, "Could not save file: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        private Uri writeToDownloads(byte[] bytes, String filename, String mimeType) throws Exception {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE,
                        mimeType != null ? mimeType : "application/octet-stream");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri item = context.getContentResolver().insert(collection, values);
                if (item == null) return null;
                try (OutputStream out = context.getContentResolver().openOutputStream(item)) {
                    if (out == null) return null;
                    out.write(bytes);
                }
                return item;
            } else {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists()) downloads.mkdirs();
                File outFile = new File(downloads, filename);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(bytes);
                }
                return FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", outFile);
            }
        }
    }
}
