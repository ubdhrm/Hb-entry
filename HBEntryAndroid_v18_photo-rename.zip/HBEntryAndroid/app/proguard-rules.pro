# WebView JS bridge: methods called from index.html must keep their names.
-keepclassmembers class com.hbentry.app.MainActivity$DownloadBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
# ML Kit barcode scanner
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
