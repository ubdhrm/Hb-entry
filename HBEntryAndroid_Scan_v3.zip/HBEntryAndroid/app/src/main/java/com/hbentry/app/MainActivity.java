package com.hbentry.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Rect;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ExperimentalGetImage;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends ComponentActivity {

    private static final int FILE_CHOOSER_REQUEST = 5001;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    // ---- Live (half-screen, continuous) barcode scanner ----
    private static final int CAMERA_REQUEST = 5002;
    private FrameLayout scanPanel;
    private PreviewView previewView;
    private TextView torchBtn;
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private BarcodeScanner barcodeScanner;
    private ExecutorService analysisExecutor;
    private ToneGenerator tone;
    private boolean scanning = false;
    private volatile boolean paused = false; // waiting for user to press OK
    private boolean torchOn = false;
    private String acceptedValue = null;   // last code sent to the page
    private long acceptedSeen = 0;         // last time that code was still in view
    private String candValue = null;       // code currently being confirmed
    private int candCount = 0;             // consecutive frames that read candValue
    private long candLast = 0;
    private static final int CONFIRM_READS = 3;   // same value this many times in a row
    private static final long CONFIRM_GAP_MS = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Top half: the app (WebView). Bottom half: camera, only while scanning.
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        webView = new WebView(this);
        root.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        buildScanPanel();
        scanPanel.setVisibility(View.GONE);
        root.addView(scanPanel, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        configureWebView(webView, true);
        webView.loadUrl("file:///android_asset/www/index.html");

        BarcodeScannerOptions opts = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_CODE_128,
                        Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_EAN_13,
                        Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_UPC_A,
                        Barcode.FORMAT_UPC_E,
                        Barcode.FORMAT_QR_CODE)
                .build();
        barcodeScanner = BarcodeScanning.getClient(opts);
        analysisExecutor = Executors.newSingleThreadExecutor();
        try { tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 80); } catch (Exception ignored) { }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView panelButton(String text, int gravity) {
        TextView b = new TextView(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setPadding(dp(14), dp(8), dp(14), dp(8));
        b.setBackgroundColor(0x99000000);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = gravity;
        lp.setMargins(dp(10), dp(10), dp(10), dp(10));
        b.setLayoutParams(lp);
        return b;
    }

    private void buildScanPanel() {
        scanPanel = new FrameLayout(this);
        scanPanel.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        scanPanel.addView(previewView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // thin red aiming line in the middle
        View line = new View(this);
        line.setBackgroundColor(0xCCFF2D2D);
        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(2));
        llp.gravity = Gravity.CENTER_VERTICAL;
        llp.setMargins(dp(32), 0, dp(32), 0);
        scanPanel.addView(line, llp);

        TextView close = panelButton("\u2715  Close", Gravity.TOP | Gravity.END);
        close.setOnClickListener(v -> stopScanning());
        scanPanel.addView(close);

        torchBtn = panelButton("Torch", Gravity.TOP | Gravity.START);
        torchBtn.setOnClickListener(v -> {
            if (camera == null || !camera.getCameraInfo().hasFlashUnit()) return;
            torchOn = !torchOn;
            camera.getCameraControl().enableTorch(torchOn);
            torchBtn.setText(torchOn ? "Torch ON" : "Torch");
        });
        scanPanel.addView(torchBtn);
    }

    void startScanning() {
        if (scanning) return;
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
            return;
        }
        scanning = true;
        paused = false;
        acceptedValue = null;
        candValue = null;
        candCount = 0;
        scanPanel.setVisibility(View.VISIBLE);
        sendScanMode(true);
        final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                cameraProvider = future.get();
                bindCamera();
            } catch (Exception e) {
                Toast.makeText(this, "Camera error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                stopScanning();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @SuppressWarnings("deprecation")
    private void bindCamera() {
        if (cameraProvider == null || !scanning) return;
        cameraProvider.unbindAll();
        Preview preview = new Preview.Builder().build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());
        ImageAnalysis analysis = new ImageAnalysis.Builder()
                .setTargetResolution(new Size(1280, 720))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build();
        analysis.setAnalyzer(analysisExecutor, this::analyze);
        camera = cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
    }

    void stopScanning() {
        boolean wasScanning = scanning;
        scanning = false;
        torchOn = false;
        if (torchBtn != null) torchBtn.setText("Torch");
        try { if (cameraProvider != null) cameraProvider.unbindAll(); } catch (Exception ignored) { }
        camera = null;
        scanPanel.setVisibility(View.GONE);
        if (wasScanning) sendScanMode(false);
    }

    @androidx.annotation.OptIn(markerClass = ExperimentalGetImage.class)
    private void analyze(ImageProxy proxy) {
        android.media.Image img = proxy.getImage();
        if (img == null || !scanning) { proxy.close(); return; }
        final int rot = proxy.getImageInfo().getRotationDegrees();
        final boolean swap = rot == 90 || rot == 270;
        final int w = swap ? proxy.getHeight() : proxy.getWidth();
        final int h = swap ? proxy.getWidth() : proxy.getHeight();
        InputImage input = InputImage.fromMediaImage(img, rot);
        barcodeScanner.process(input)
                .addOnSuccessListener(list -> onDetected(list, w, h))
                .addOnCompleteListener(t -> proxy.close());
    }

    /** If several barcodes are visible, take the one closest to the centre line. */
    private void onDetected(List<Barcode> list, int w, int h) {
        if (!scanning || list == null || list.isEmpty()) return;
        String best = null;
        double bestDist = Double.MAX_VALUE;
        for (Barcode b : list) {
            String v = b.getRawValue();
            if (v == null || v.trim().isEmpty()) continue;
            // Same label can decode as "105752" or "105-52": keep letters/digits only.
            v = v.replaceAll("[^A-Za-z0-9]", "");
            // Item numbers are digits only. A value with letters (e.g. "1057V") is a bad read.
            if (v.isEmpty() || !v.matches("\\d+")) continue;
            Rect r = b.getBoundingBox();
            double d = 0;
            if (r != null) {
                double dx = r.centerX() - w / 2.0, dy = r.centerY() - h / 2.0;
                d = dx * dx + dy * dy;
            }
            if (d < bestDist) { bestDist = d; best = v; }
        }
        if (best == null) return;
        long now = SystemClock.elapsedRealtime();
        // Already added and still in view -> not a new scan.
        if (best.equals(acceptedValue) && (now - acceptedSeen) < 1200) {
            acceptedSeen = now;
            return;
        }
        if (paused) return; // popup open, waiting for OK / Skip
        // Accept only after the same value is read several frames in a row.
        if (best.equals(candValue) && (now - candLast) < CONFIRM_GAP_MS) {
            candCount++;
        } else {
            candValue = best;
            candCount = 1;
        }
        candLast = now;
        if (candCount < CONFIRM_READS) return;
        acceptedValue = best;
        acceptedSeen = now;
        candValue = null;
        candCount = 0;
        paused = true; // no more scans until the user presses OK
        feedback();
        sendScanToJs(best, "");
    }

    private void feedback() {
        try { if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120); } catch (Exception ignored) { }
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null) {
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(50);
                }
            }
        } catch (Exception ignored) { }
    }

    void sendScanMode(boolean on) {
        final String js = "window.onScanMode && window.onScanMode(" + (on ? "true" : "false") + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startScanning();
            } else {
                Toast.makeText(this, "Camera permission is needed to scan", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { if (analysisExecutor != null) analysisExecutor.shutdown(); } catch (Exception ignored) { }
        try { if (barcodeScanner != null) barcodeScanner.close(); } catch (Exception ignored) { }
        try { if (tone != null) tone.release(); } catch (Exception ignored) { }
    }

    @SuppressWarnings("SetJavaScriptEnabled")
    private void configureWebView(final WebView wv, final boolean isMain) {
        WebSettings settings = wv.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        wv.setWebViewClient(new WebViewClient());
        wv.addJavascriptInterface(new DownloadBridge(this), "AndroidDownload");

        wv.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.confirm())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new android.app.AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (dialog, which) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .setCancelable(true)
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                              FileChooserParams params) {
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            // "Saved bills" opens via window.open('', '_blank'); show it in a
            // full-screen dialog backed by its own WebView with the same bridges.
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                final Dialog dialog = new Dialog(MainActivity.this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
                FrameLayout container = new FrameLayout(MainActivity.this);
                final WebView popupWebView = new WebView(MainActivity.this);
                configureWebView(popupWebView, false);
                container.addView(popupWebView, new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
                dialog.setContentView(container);
                Window window = dialog.getWindow();
                if (window != null) {
                    window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                }
                dialog.setOnDismissListener(d -> popupWebView.destroy());
                popupWebView.setWebViewClient(new WebViewClient());

                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popupWebView);
                resultMsg.sendToTarget();

                dialog.show();
                popupWebView.setOnKeyListener((v, keyCode, event) -> {
                    if (keyCode == android.view.KeyEvent.KEYCODE_BACK && popupWebView.canGoBack()) {
                        popupWebView.goBack();
                        return true;
                    }
                    return false;
                });
                // Allow closing the popup with the system back gesture/button.
                dialog.setCancelable(true);
                return true;
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                } else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /** Sends a scan result (or error) back to the page: window.onBarcodeScanned(value, error). */
    void sendScanToJs(String value, String error) {
        final String js = "window.onBarcodeScanned && window.onBarcodeScanned("
                + org.json.JSONObject.quote(value) + "," + org.json.JSONObject.quote(error) + ");";
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(js, null); });
    }

    @Override
    public void onBackPressed() {
        if (scanning) { stopScanning(); return; }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        super.onBackPressed();
    }

    /**
     * Shows a full HTML string (built entirely in JS, e.g. the "Saved bills"
     * screen) in a full-screen dialog backed by its own WebView, loaded via
     * loadDataWithBaseURL so it counts as a real page load. That matters
     * because android.webkit.WebView only binds addJavascriptInterface
     * objects (like AndroidDownload) on to a page's JS context during an
     * actual navigation/load — a WebView that only ever receives content via
     * document.write() (as window.open() + document.write() does) never gets
     * the bridge, which is why the WhatsApp share button silently couldn't
     * reach AndroidDownload before this method existed.
     */
    void showHtmlDialog(String html) {
        final Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout container = new FrameLayout(this);
        final WebView popupWebView = new WebView(this);
        configureWebView(popupWebView, false);
        container.addView(popupWebView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        dialog.setContentView(container);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        }
        dialog.setOnDismissListener(d -> popupWebView.destroy());
        // A non-null baseUrl matching the main page's origin is required so this
        // popup's localStorage (used by the Delete button) is the same storage
        // the main page reads/writes — loadDataWithBaseURL(null, ...) instead
        // gives the page a unique opaque origin with no storage access at all.
        popupWebView.loadDataWithBaseURL(
                "file:///android_asset/www/index.html", html, "text/html", "UTF-8", null);
        dialog.show();
        popupWebView.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == android.view.KeyEvent.KEYCODE_BACK && popupWebView.canGoBack()) {
                popupWebView.goBack();
                return true;
            }
            return false;
        });
        dialog.setCancelable(true);
    }

    /**
     * JS bridge that receives a base64-encoded file (PDF/JSON export produced by
     * the page's own download buttons) and saves it to the device's Downloads,
     * then offers a share sheet (so "WhatsApp" buttons work the same as on the web).
     */
    public static class DownloadBridge {
        private final Context context;

        DownloadBridge(Context context) {
            this.context = context;
        }

        @JavascriptInterface
        public void scanBarcode() {
            if (!(context instanceof MainActivity)) return;
            final MainActivity activity = (MainActivity) context;
            activity.runOnUiThread(activity::startScanning);
        }

        @JavascriptInterface
        public void resumeScan() {
            if (!(context instanceof MainActivity)) return;
            final MainActivity activity = (MainActivity) context;
            activity.acceptedSeen = android.os.SystemClock.elapsedRealtime();
            activity.paused = false;
        }

        @JavascriptInterface
        public void stopScan() {
            if (!(context instanceof MainActivity)) return;
            final MainActivity activity = (MainActivity) context;
            activity.runOnUiThread(activity::stopScanning);
        }

        @JavascriptInterface
        public void openHtmlWindow(final String html) {
            if (!(context instanceof MainActivity)) return;
            final MainActivity activity = (MainActivity) context;
            activity.runOnUiThread(() -> activity.showHtmlDialog(html));
        }

        @JavascriptInterface
        public void saveBase64File(final String base64Data, final String filename, final String mimeType) {
            ((Activity) context).runOnUiThread(() -> {
                try {
                    byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
                    Uri savedUri = writeToDownloads(bytes, filename, mimeType);
                    if (savedUri == null) {
                        Toast.makeText(context, "Could not save " + filename, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(context, "Saved to Downloads: " + filename, Toast.LENGTH_SHORT).show();

                    Intent share = new Intent(Intent.ACTION_SEND);
                    share.setType(mimeType != null ? mimeType : "application/octet-stream");
                    share.putExtra(Intent.EXTRA_STREAM, savedUri);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent chooser = Intent.createChooser(share, "Share " + filename);
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(chooser);
                } catch (Exception e) {
                    Toast.makeText(context, "Could not save file: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        private Uri writeToDownloads(byte[] bytes, String filename, String mimeType) throws Exception {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                values.put(MediaStore.MediaColumns.MIME_TYPE,
                        mimeType != null ? mimeType : "application/octet-stream");
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                Uri item = context.getContentResolver().insert(collection, values);
                if (item == null) return null;
                try (OutputStream out = context.getContentResolver().openOutputStream(item)) {
                    if (out == null) return null;
                    out.write(bytes);
                }
                return item;
            } else {
                File downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!downloads.exists()) downloads.mkdirs();
                File outFile = new File(downloads, filename);
                try (FileOutputStream fos = new FileOutputStream(outFile)) {
                    fos.write(bytes);
                }
                return FileProvider.getUriForFile(context, context.getPackageName() + ".fileprovider", outFile);
            }
        }
    }
}
